import React from 'react'

const EditGames = () => {
  return (
    <div>EditGames</div>
  )
}

export default EditGames