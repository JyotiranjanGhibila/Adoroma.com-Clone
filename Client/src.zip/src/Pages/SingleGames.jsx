import React from 'react'
import GameCard from "../Components/Products/GameCard"

const SingleGames = () => {
 
  return (
    <div>
      <h1>Single Games</h1>
      <GameCard/>
    </div>
  )
}

export default SingleGames