import React from 'react'

const AllComponents = () => {
  return (
    <div>AllComponents</div>
  )
}

export default AllComponents