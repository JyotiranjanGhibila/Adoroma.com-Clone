const news=[
    {
        img:"https://www.adorama.com/alc/wp-content/uploads/2023/02/Sony50-03.jpg",
        title:"Sony G-Master FE 50mm f/1.4 Lens: Hands-On Review"
    },
    {
        img:"https://www.adorama.com/alc/wp-content/uploads/2021/12/Best-Budget-Home-Theater-Speakers-e1676478487607.jpg",
        title:"Best Budget Home Theater Speakers"
    },
    {
        img:"https://www.adorama.com/alc/wp-content/uploads/2023/02/Velvet-Alchemy-Photos-0769.jpg",
        title:"Tips from a Las Vegas Elopement Photographer"
    },
    {
        img:"https://www.adorama.com/alc/wp-content/uploads/2023/02/90mm-BTS-13.jpg",
        title:"OM System M.Zuiko 90mm f/3.5 Macro IS PRO Lens"
    },
    {
        img:"https://www.adorama.com/alc/wp-content/uploads/2023/02/Lindsay-Adler-Red-Fashion19543-EE8A5732.jpg",
        title:"How to Use the Color Red in Photography"
    },
    {
        img:"https://www.adorama.com/alc/wp-content/uploads/2023/02/Canon-Entry-Level-Cams-LIFTS_2.13.1-1.png",
        title:"Canon Releases Two New Cameras, R50 and R8"
    },
    {
        img:"https://www.adorama.com/alc/wp-content/uploads/2023/02/Nikon8526Product-4.jpg",
        title:"Nikon NIKKOR Z 85mm f/1.2 S Lens"
    }
]
export default news