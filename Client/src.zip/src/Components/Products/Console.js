const Con=[
    {
        img:"https://www.adorama.com/images/Large/sops5gowb.jpg",
        title:"Sony PlayStation 5 825GB Gaming Console with God of War Ragnarok, Standard Edition",
        price:559,
        tag:"BestSeller",
        id:1
    },
    {
        img:"https://www.adorama.com/images/Large/mirrs25.jpg",
        title:"Microsoft Xbox Series S 512GB Gaming Console, White",
        price:249,
        tag:"BestSeller",
        id:2
    },
    
    {
        img:"https://www.adorama.com/images/Large/asvg27aq.jpg",
        title:"Asus TUF VG27AQ 27 16:9 QHD 165Hz IPS HDR Gaming Monitor with G-SYNC/Adaptive Sync",
        price:397,
        tag:"BestSeller",
        id:3
    },
    {
        img:"https://www.adorama.com/images/product/tm5gf628.jpg",
        title:"Thrustmaster T.Flight HOTAS 4 Flight Stick for PlayStation and PC",
        price:3699,
        tag:"BestSeller",
        id:4
    },
    
    {
        img:"https://www.adorama.com/images/Large/vrjaero.jpg",
        title:"Varjo Aero Virtual Reality Headset",
        price:1990,
        tag:"BestSeller",
        id:6
    },
    {
        img:"https://www.adorama.com/images/Large/hosb003011.jpg",
        title:"Honeycomb Alpha Flight Controls Yoke and Switch Panel",
        price:439,
        tag:"BestSeller",
        id:7
    }
]
export default Con