const Plat = [
  {
    img: "https://www.adorama.com/col/_gaming/l1/Platform_Playstation_Desktop.jpg",
  },
  {
    img: "https://www.adorama.com/col/_gaming/l1/Platform_XBox_Desktop.jpg",
  },
  {
    img: "https://www.adorama.com/col/_gaming/l1/Platform_Switch_Desktop.jpg",
  },
  {
    img: "https://www.adorama.com/col/_gaming/l1/Platform_Retro_Desktop.jpg",
  },
  {
    img: "https://www.adorama.com/col/_gaming/l1/Platform_PC_Desktop.jpg",
  },
  {
    img: "https://www.adorama.com/col/_gaming/l1/Platform_VR_Desktop.jpg",
  },
];

export default Plat;
