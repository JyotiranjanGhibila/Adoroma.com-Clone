const Fgames=[
    {
        img:"https://www.adorama.com/images/cms/33095God_of_War_Ragnarok_-_Desktop_05765.jpg",
        link:"https://www.adorama.com/sogowrps5.html"
    },
    {
        img:"https://www.adorama.com/images/cms/33095Pokemon_Scarlet_and_Pokemon_Violet_Double_Pack_-_Desktop_(1)_49286.jpg",
        link:"https://www.adorama.com/nipkmscrvlt.html"
    },
    {
        img:"https://www.adorama.com/images/cms/33095EA-Fifa23-Featured-Game-Desktop_33103.jpg",
        link:"https://www.adorama.com/eafifa23xsx.html"
    },
    {
        img:"https://www.adorama.com/images/cms/33095COD-MW2-Featured-Game-Desktop_86677.jpg",
        link:"https://www.adorama.com/so74720.html"
    }
]
export default Fgames;