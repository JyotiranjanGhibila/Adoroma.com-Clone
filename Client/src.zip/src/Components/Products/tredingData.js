const Tred=[
    {
        img:"https://www.adorama.com/images/product/pcs5m2k.jpg",
        title:"Panasonic LUMIX S5 II Mirrorless Digital Camera with Lumix S 20-60mm f/3.5-5.6 Lens,",
        price:2297,
        tag:"NewArrivals",
        id:1
    },
    {
        img:"https://www.adorama.com/images/product/ikkwpz2bl.jpg",
        title:"Kodak PIXPRO WPZ2 Waterproof Rugged Digital Camera, Blue",
        price:149,
        tag:"NewArrivals",
        id:2
    },
    
    {
        img:"https://www.adorama.com/images/product/sg60600l.jpg",
        title:"Sigma 60-600mm f/4.5-6.3 DG DN OS Sports Lens for Leica L",
        price:1399,
        tag:"NewArrivals",
        id:3
    },
    {
        img:"https://www.adorama.com/images/product/car5.jpg",
        title:"Canon EOS R5 Mirrorless Digital Camera Body",
        price:3699,
        tag:"NewArrivals",
        id:4
    },
    
    {
        img:"https://www.adorama.com/images/product/fplfbl200v.jpg",
        title:"Flashpoint BLAZ 200-V 200Ws R2 Studio Monolight Flash With 10W LED Modeling Lamp and Bowens Mount",
        price:190,
        tag:"NewArrivals",
        id:6
    },
    {
        img:"https://www.adorama.com/images/Large/ipcdmczs80bd.jpg",
        title:"Panasonic Lumix DC-ZS80 Digital Camera, Black with Essential Accessories Kit",
        price:439,
        tag:"NewArrivals",
        id:7
    }
]
export default Tred