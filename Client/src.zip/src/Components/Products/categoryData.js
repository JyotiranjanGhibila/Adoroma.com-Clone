const cate = [
    {
      img: "https://www.adorama.com/images/cms/15616isoa7r4_98448.jpg",
      title: "Cameras",
    },
    {
      img: "https://www.adorama.com/images/cms/15616lenses_47765.jpg",
      title: "Lenses",
    },
    {
      img: "https://www.adorama.com/images/cms/15616lighting_81170.jpg",
      title: "Lighting&Studio",
    },
    {
      img: "https://www.adorama.com/images/cms/15616tripod_89995.jpg",
      title: "Tripod",
    },
    {
      img: "https://www.adorama.com/images/cms/15616battery_grip_09677.jpg",
      title: "Cameras Accessories",
    },
    {
      img: "https://www.adorama.com/images/cms/15616lens_accessory_44970.jpg",
      title: "Lense Accessories",
    },
    {
      img: "https://www.adorama.com/images/cms/15616Lens_Filter_37689.jpg",
      title: "Lenses Filter",
    },
    {
      img: "https://www.adorama.com/images/cms/15616underwater_50466.jpg",
      title: "Underwater Photography",
    },
    {
      img: "https://www.adorama.com/images/cms/15616mobile_photography_89004.jpg",
      title: "Mobile Photography",
    },
    {
      img: "https://www.adorama.com/images/cms/15616memory_card_photography_78143.jpg",
      title: "Memory Cards",
    },
    {
      img: "https://www.adorama.com/images/cms/15616frames_53390.jpg",
      title: "Albums Frames",
    },
    {
      img: "https://www.adorama.com/images/cms/15616backpacks_10788.jpg",
      title: "Bags & Cases",
    },
  ];

  export default cate;